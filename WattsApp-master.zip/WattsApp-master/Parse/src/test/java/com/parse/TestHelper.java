package com.parse;

/**
 * Helper class for testing
 */
public class TestHelper {

  public static final int ROBOLECTRIC_SDK_VERSION = 25;
}
